# NSUT Tracker

Attendance + semester-wise CGPA tracker, with an opt-in leaderboard. Built to run entirely on free tiers.

## 1. Set up the backend (Supabase, free)

1. Go to supabase.com → New project (free tier: 500MB DB, 50k monthly users — more than enough).
2. Once created, open **SQL Editor** → paste the contents of `supabase_schema.sql` → Run.
3. Go to **Project Settings → API** → copy the `Project URL` and `anon public` key.
4. In **Authentication → Providers**, keep Email enabled. Optional: under **Authentication → URL Configuration**, you can restrict sign-ups to `@nsut.ac.in` addresses using an email domain check (Supabase Auth Hooks) — ask me if you want this wired in.

## 2. Run it locally

```
cp .env.example .env      # paste your Supabase URL + anon key
npm install
npm run dev
```

## 3. Deploy for free

Push this folder to a GitHub repo, then:

1. Go to vercel.com → New Project → import the repo.
2. Add the two env vars (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`) in the Vercel project settings.
3. Deploy. You get a free `yourapp.vercel.app` URL, free SSL, no card required.

(Netlify or Cloudflare Pages work identically if you prefer those.)

## 4. Getting it onto students' phones — no app store needed

This is built as a **PWA (installable web app)**:
- On Android (Chrome): visiting the site shows an "Install app" prompt, or Menu → "Add to Home screen." It then behaves like a native app — own icon, own window, works offline for cached pages.
- On iPhone (Safari): Share → "Add to Home Screen."

This is genuinely free and skips app-store review entirely — good enough for a college-wide utility app.

## 5. If you specifically want it on the Play Store

Two honest facts:
- Google charges a **one-time $25 registration fee** for a Play Store developer account. There's no free way around this — it's Google's fee, not a hosting cost.
- If you're fine with that one-time cost, wrap the PWA with [Bubblewrap](https://github.com/GoogleChromeLabs/bubblewrap) (Google's own free tool that packages a PWA into an Android `.apk`/`.aab` using Trusted Web Activity) — no separate native rewrite needed.
- Free alternative to Play Store: distribute the `.apk` directly (e.g. a GitHub Releases link) for students to sideload, or just push people to the installable web link above.

## 6. Ongoing cost reality check

At NSUT's scale (a few thousand students), you'll comfortably stay inside:
- Supabase free tier (500MB DB, 50k MAUs, 2GB file storage)
- Vercel free tier (100GB bandwidth/month)

If the app ever outgrows free tiers, that's a nice problem — but it won't happen at a single college's scale for a text-heavy app like this.

## Design notes

- Students self-report attendance and SGPA. This is deliberate: NSUT has no public API, and building a scraper that logs into the ERP with student passwords would mean storing student credentials — a real security and ToS risk not worth taking for a free side project.
- Leaderboard is **opt-in and off by default** — a student's CGPA is sensitive, so nothing is shown until they explicitly turn it on and pick a display name.
