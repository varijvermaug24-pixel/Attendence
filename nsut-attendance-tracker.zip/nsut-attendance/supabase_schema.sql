-- Run this once in Supabase: Project → SQL Editor → New query → paste all → Run

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  leaderboard_opt_in boolean default false,
  created_at timestamptz default now()
);

create table subjects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  semester int not null,
  name text not null,
  attended int default 0,
  total int default 0,
  created_at timestamptz default now()
);

create table semester_gpa (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  semester int not null,
  sgpa numeric(4,2) not null,
  unique (user_id, semester)
);

-- auto-create a profile row when someone signs up
create function public.handle_new_user() returns trigger as $$
begin
  insert into public.profiles (id) values (new.id);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- leaderboard only ever exposes rows the student opted into, and only name + sgpa
create view leaderboard_view as
  select g.id, g.semester, g.sgpa, p.display_name
  from semester_gpa g
  join profiles p on p.id = g.user_id
  where p.leaderboard_opt_in = true;

-- Row Level Security: everyone can only touch their own rows
alter table profiles enable row level security;
alter table subjects enable row level security;
alter table semester_gpa enable row level security;

create policy "own profile" on profiles for all using (auth.uid() = id);
create policy "own subjects" on subjects for all using (auth.uid() = user_id);
create policy "own gpa" on semester_gpa for all using (auth.uid() = user_id);

-- the leaderboard view is safe to expose publicly since it's pre-filtered to opt-ins only
grant select on leaderboard_view to authenticated;
