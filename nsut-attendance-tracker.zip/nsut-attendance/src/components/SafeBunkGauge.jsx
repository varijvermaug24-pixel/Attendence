export default function SafeBunkGauge({ attended, total, threshold = 75 }) {
  const pct = total === 0 ? 0 : (attended / total) * 100
  const safe = pct >= threshold

  // classes that can still be missed while staying >= threshold
  const canMiss = Math.max(0, Math.floor((attended - (threshold / 100) * total) / (threshold / 100)))
  // classes needed to attend consecutively to reach threshold
  const needToAttend = safe ? 0 : Math.ceil((threshold * total - 100 * attended) / (100 - threshold))

  return (
    <div className="card">
      <div className="eyebrow">Overall attendance</div>
      <div className="gauge-wrap">
        <div>
          <div className="gauge-num" style={{ color: safe ? 'var(--sage-dark)' : 'var(--coral-dark)' }}>
            {pct.toFixed(1)}%
          </div>
          <div className="gauge-label">{attended} / {total} classes attended</div>
        </div>
        <div style={{ flex: 1, textAlign: 'right' }}>
          {safe ? (
            <>
              <div className="gauge-num" style={{ fontSize: 28 }}>{canMiss}</div>
              <div className="gauge-label">classes you can still skip</div>
            </>
          ) : (
            <>
              <div className="gauge-num" style={{ fontSize: 28, color: 'var(--coral-dark)' }}>{needToAttend}</div>
              <div className="gauge-label">classes to attend in a row to hit {threshold}%</div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
