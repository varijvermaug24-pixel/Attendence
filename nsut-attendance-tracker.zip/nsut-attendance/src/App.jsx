import { useEffect, useState } from 'react'
import { HashRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom'
import { supabase } from './lib/supabaseClient'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Cgpa from './pages/Cgpa'
import Leaderboard from './pages/Leaderboard'

export default function App() {
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setLoading(false) })
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s))
    return () => sub.subscription.unsubscribe()
  }, [])

  if (loading) return null
  if (!session) return <Login />

  return (
    <HashRouter>
      <div className="app-shell">
        <Routes>
          <Route path="/" element={<Dashboard session={session} />} />
          <Route path="/cgpa" element={<Cgpa session={session} />} />
          <Route path="/leaderboard" element={<Leaderboard session={session} />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
      <nav className="tab-bar">
        <NavLink to="/" className={({ isActive }) => `tab-item ${isActive ? 'active' : ''}`}>Attendance</NavLink>
        <NavLink to="/cgpa" className={({ isActive }) => `tab-item ${isActive ? 'active' : ''}`}>CGPA</NavLink>
        <NavLink to="/leaderboard" className={({ isActive }) => `tab-item ${isActive ? 'active' : ''}`}>Leaderboard</NavLink>
        <a className="tab-item" href="#" onClick={() => supabase.auth.signOut()}>Sign out</a>
      </nav>
    </HashRouter>
  )
}
