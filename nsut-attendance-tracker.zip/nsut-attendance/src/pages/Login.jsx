import { useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [mode, setMode] = useState('signin')
  const [error, setError] = useState('')
  const [sent, setSent] = useState(false)

  async function submit() {
    setError('')
    if (mode === 'signin') {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) setError(error.message)
    } else {
      const { error } = await supabase.auth.signUp({ email, password })
      if (error) setError(error.message)
      else setSent(true)
    }
  }

  return (
    <div className="app-shell" style={{ paddingTop: '3rem' }}>
      <h1 style={{ marginBottom: 8 }}>NSUT Tracker</h1>
      <p style={{ color: 'var(--slate)', marginTop: 0 }}>Attendance and CGPA, in one place.</p>

      {sent ? (
        <p>Check your inbox for a confirmation link, then sign in.</p>
      ) : (
        <div className="card">
          <div className="field">
            <label>College email</label>
            <input placeholder="you@nsut.ac.in" value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div className="field">
            <label>Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          {error && <p style={{ color: 'var(--coral-dark)', fontSize: 13 }}>{error}</p>}
          <button className="btn btn-mark" style={{ width: '100%' }} onClick={submit}>
            {mode === 'signin' ? 'Sign in' : 'Create account'}
          </button>
          <p style={{ fontSize: 13, textAlign: 'center', marginTop: 12 }}>
            {mode === 'signin' ? (
              <span>New here? <a href="#" onClick={() => setMode('signup')}>Create an account</a></span>
            ) : (
              <span>Already have one? <a href="#" onClick={() => setMode('signin')}>Sign in</a></span>
            )}
          </p>
        </div>
      )}
    </div>
  )
}
