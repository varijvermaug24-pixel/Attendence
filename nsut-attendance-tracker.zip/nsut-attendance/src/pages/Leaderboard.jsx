import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

export default function Leaderboard({ session }) {
  const [semester, setSemester] = useState(1)
  const [rows, setRows] = useState([])
  const [optedIn, setOptedIn] = useState(false)
  const [displayName, setDisplayName] = useState('')

  async function load() {
    const { data } = await supabase
      .from('leaderboard_view')
      .select('*')
      .eq('semester', semester)
      .order('sgpa', { ascending: false })
      .limit(50)
    setRows(data || [])

    const { data: profile } = await supabase.from('profiles')
      .select('leaderboard_opt_in, display_name').eq('id', session.user.id).single()
    if (profile) {
      setOptedIn(profile.leaderboard_opt_in)
      setDisplayName(profile.display_name || '')
    }
  }
  useEffect(() => { load() }, [semester])

  async function toggleOptIn() {
    const next = !optedIn
    await supabase.from('profiles').update({ leaderboard_opt_in: next }).eq('id', session.user.id)
    setOptedIn(next)
    load()
  }

  async function saveName() {
    await supabase.from('profiles').update({ display_name: displayName }).eq('id', session.user.id)
    load()
  }

  return (
    <div>
      <div className="top-bar">
        <h1>Leaderboard</h1>
        <select value={semester} onChange={e => setSemester(Number(e.target.value))}>
          {Array.from({ length: 8 }, (_, i) => i + 1).map(n => (
            <option key={n} value={n}>Semester {n}</option>
          ))}
        </select>
      </div>

      <div className="card">
        <div className="eyebrow" style={{ marginBottom: 8 }}>Your visibility</div>
        <p style={{ fontSize: 14, color: 'var(--slate)', marginTop: 0 }}>
          Off by default. Turn this on if you want your SGPA shown on the leaderboard under a display name of your choice.
        </p>
        <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
          <input placeholder="Display name, e.g. topper_23" value={displayName}
            onChange={e => setDisplayName(e.target.value)} />
          <button className="btn btn-outline" onClick={saveName}>Save</button>
        </div>
        <button className="btn btn-mark" onClick={toggleOptIn}>
          {optedIn ? 'Leave leaderboard' : 'Join leaderboard'}
        </button>
      </div>

      <div className="card">
        {rows.length === 0 && <p style={{ color: 'var(--slate)', fontSize: 14 }}>No entries yet for this semester.</p>}
        {rows.map((r, i) => (
          <div className="leader-row" key={r.id}>
            <div style={{ display: 'flex' }}>
              <span className="leader-rank">{i + 1}</span>
              <span>{r.display_name || 'Anonymous'}</span>
            </div>
            <span className="leader-cgpa">{Number(r.sgpa).toFixed(2)}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
