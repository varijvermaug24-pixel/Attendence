import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import SafeBunkGauge from '../components/SafeBunkGauge'

export default function Dashboard({ session }) {
  const [subjects, setSubjects] = useState([])
  const [semester, setSemester] = useState(1)
  const [newSubject, setNewSubject] = useState('')

  async function loadSubjects() {
    const { data } = await supabase
      .from('subjects')
      .select('*')
      .eq('user_id', session.user.id)
      .eq('semester', semester)
      .order('created_at')
    setSubjects(data || [])
  }

  useEffect(() => { loadSubjects() }, [semester])

  async function addSubject() {
    if (!newSubject.trim()) return
    await supabase.from('subjects').insert({
      user_id: session.user.id, name: newSubject.trim(), semester,
      attended: 0, total: 0
    })
    setNewSubject('')
    loadSubjects()
  }

  async function mark(subject, present) {
    await supabase.from('subjects').update({
      total: subject.total + 1,
      attended: subject.attended + (present ? 1 : 0)
    }).eq('id', subject.id)
    loadSubjects()
  }

  const totals = subjects.reduce((acc, s) => ({
    attended: acc.attended + s.attended, total: acc.total + s.total
  }), { attended: 0, total: 0 })

  return (
    <div>
      <div className="top-bar">
        <h1>Your dashboard</h1>
        <select value={semester} onChange={e => setSemester(Number(e.target.value))}>
          {Array.from({ length: 8 }, (_, i) => i + 1).map(n => (
            <option key={n} value={n}>Semester {n}</option>
          ))}
        </select>
      </div>

      <SafeBunkGauge attended={totals.attended} total={totals.total} />

      <div className="card">
        <div className="eyebrow" style={{ marginBottom: 8 }}>Subjects this semester</div>
        {subjects.length === 0 && <p style={{ color: 'var(--slate)', fontSize: 14 }}>No subjects yet — add one below.</p>}
        {subjects.map(s => {
          const pct = s.total === 0 ? 0 : (s.attended / s.total) * 100
          return (
            <div className="subject-row" key={s.id}>
              <div>
                <div className="subject-name">{s.name}</div>
                <div className={`subject-pct ${pct >= 75 ? 'pct-safe' : 'pct-risk'}`}>
                  {pct.toFixed(0)}% · {s.attended}/{s.total}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-outline" onClick={() => mark(s, false)}>Absent</button>
                <button className="btn btn-mark" onClick={() => mark(s, true)}>Present</button>
              </div>
            </div>
          )
        })}
        <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
          <input placeholder="Add a subject, e.g. Data Structures" value={newSubject}
            onChange={e => setNewSubject(e.target.value)} />
          <button className="btn btn-mark" onClick={addSubject}>Add</button>
        </div>
      </div>
    </div>
  )
}
