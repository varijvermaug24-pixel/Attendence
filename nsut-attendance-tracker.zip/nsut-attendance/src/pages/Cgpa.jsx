import { useEffect, useState } from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts'
import { supabase } from '../lib/supabaseClient'

export default function Cgpa({ session }) {
  const [records, setRecords] = useState([])
  const [semester, setSemester] = useState(1)
  const [sgpa, setSgpa] = useState('')

  async function load() {
    const { data } = await supabase
      .from('semester_gpa')
      .select('*')
      .eq('user_id', session.user.id)
      .order('semester')
    setRecords(data || [])
  }
  useEffect(() => { load() }, [])

  async function save() {
    const value = parseFloat(sgpa)
    if (isNaN(value) || value < 0 || value > 10) return
    await supabase.from('semester_gpa').upsert({
      user_id: session.user.id, semester, sgpa: value
    }, { onConflict: 'user_id,semester' })
    setSgpa('')
    load()
  }

  const cgpa = records.length
    ? (records.reduce((a, r) => a + Number(r.sgpa), 0) / records.length).toFixed(2)
    : '—'

  const chartData = records.map(r => ({
    name: `Sem ${r.semester}`, sgpa: Number(r.sgpa),
    year: `Year ${Math.ceil(r.semester / 2)}`
  }))

  return (
    <div>
      <div className="top-bar"><h1>CGPA tracker</h1></div>

      <div className="card">
        <div className="eyebrow">Overall CGPA</div>
        <div className="gauge-num">{cgpa}</div>
        <div className="gauge-label">across {records.length} semester{records.length === 1 ? '' : 's'}</div>
      </div>

      {chartData.length > 0 && (
        <div className="card" style={{ height: 220 }}>
          <div className="eyebrow" style={{ marginBottom: 8 }}>Semester-wise trend</div>
          <ResponsiveContainer width="100%" height="90%">
            <LineChart data={chartData}>
              <CartesianGrid stroke="#E4E1D8" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11, fontFamily: 'JetBrains Mono' }} />
              <YAxis domain={[0, 10]} tick={{ fontSize: 11, fontFamily: 'JetBrains Mono' }} />
              <Tooltip />
              <Line type="monotone" dataKey="sgpa" stroke="#14213D" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <div className="card">
        <div className="eyebrow" style={{ marginBottom: 8 }}>Add / update a semester's SGPA</div>
        <div className="field">
          <label>Semester</label>
          <select value={semester} onChange={e => setSemester(Number(e.target.value))}>
            {Array.from({ length: 8 }, (_, i) => i + 1).map(n => (
              <option key={n} value={n}>Semester {n} (Year {Math.ceil(n / 2)})</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>SGPA</label>
          <input type="number" step="0.01" min="0" max="10" placeholder="e.g. 8.42" value={sgpa}
            onChange={e => setSgpa(e.target.value)} />
        </div>
        <button className="btn btn-mark" onClick={save}>Save</button>
      </div>
    </div>
  )
}
